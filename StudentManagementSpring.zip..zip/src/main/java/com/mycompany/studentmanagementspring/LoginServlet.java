
package com.mycompany.studentmanagementspring;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    private static final String DB_URL =
            "jdbc:mysql://localhost:3306/student_management";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        String sql = "SELECT role, roll_no, student_id "
                   + "FROM users "
                   + "WHERE username = ? AND password = ?";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection con = DriverManager.getConnection(
                        DB_URL, DB_USER, DB_PASSWORD);
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, username);
                ps.setString(2, password);

                try (ResultSet rs = ps.executeQuery()) {

                    if (rs.next()) {

                        String role = rs.getString("role");

                        HttpSession session = request.getSession();
                        session.setAttribute("username", username);
                        session.setAttribute("role", role);

                        // Student accounts use roll_no to find
                        // their matching record in the students table.
                        if ("student".equalsIgnoreCase(role)) {

                            int rollNo = rs.getInt("roll_no");

                            if (rs.wasNull()) {
                                session.invalidate();
                                response.sendRedirect(
                                    request.getContextPath()
                                    + "/login.jsp?error=studentid");
                                return;
                            }

                            session.setAttribute("student_id", rollNo);
                        }

                        response.sendRedirect(
                            request.getContextPath()
                            + "/dashboard.jsp");

                    } else {
                        response.sendRedirect(
                            request.getContextPath()
                            + "/login.jsp?error=1");
                    }
                }

            }

        } catch (Exception e) {
            throw new ServletException(
                    "Database login failed.", e);
        }
    }
}
